plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.clipkatarnak.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.clipkatarnak.v2"
        minSdk = 24
        targetSdk = 28          // 28 rakha hai taaki bundled ffmpeg/yt-dlp binaries phone par chal sakein
        versionCode = 5
        versionName = "1.4"
        ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a") }
    }
    signingConfigs {
        create("ck") {
            storeFile = file("ck.keystore")
            storePassword = "clipkatarnak"
            keyAlias = "ck"
            keyPassword = "clipkatarnak"
        }
    }
    buildTypes {
        debug { signingConfig = signingConfigs.getByName("ck") }
        release { isMinifyEnabled = false; signingConfig = signingConfigs.getByName("ck") }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
    packaging { jniLibs { useLegacyPackaging = true } }
    lint { abortOnError = false; checkReleaseBuilds = false }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation(platform("androidx.compose:compose-bom:2024.10.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    val ytdl = "0.18.1"
    implementation("io.github.junkfood02.youtubedl-android:library:$ytdl")
    implementation("io.github.junkfood02.youtubedl-android:ffmpeg:$ytdl")

    implementation("com.google.mlkit:face-detection:16.1.7")
}
