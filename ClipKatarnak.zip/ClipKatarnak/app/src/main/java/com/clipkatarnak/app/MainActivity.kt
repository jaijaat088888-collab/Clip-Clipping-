package com.clipkatarnak.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import kotlin.concurrent.thread

private val BG = Color(0xFF0B0319)
private val CARD = Color(0xFF17102E)
private val PINK = Color(0xFFFF2E93)
private val CYAN = Color(0xFF19E3FF)
private val MUT = Color(0xFFA99CD6)
private val LINE = Color(0xFF3A2A6B)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE), 1)
        }
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = PINK, secondary = CYAN, background = BG, surface = CARD)) {
                Screen()
            }
        }
    }
}

@Composable
fun Chip(text: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val bg = if (selected) Brush.horizontalGradient(listOf(PINK, Color(0xFFFF7A3D))) else Brush.horizontalGradient(listOf(Color(0xFF0E0822), Color(0xFF0E0822)))
    Box(
        modifier.clip(RoundedCornerShape(14.dp)).background(bg).clickable { onClick() }.padding(vertical = 13.dp, horizontal = 10.dp),
        contentAlignment = Alignment.Center
    ) { Text(text, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp) }
}

@Composable
fun Label(t: String) {
    Text(t.uppercase(), color = CYAN, fontWeight = FontWeight.SemiBold, fontSize = 12.sp, modifier = Modifier.padding(top = 16.dp, bottom = 6.dp))
}

@Composable
fun Screen() {
    val ctx = LocalContext.current
    val act = ctx as ComponentActivity
    var url by remember { mutableStateOf("") }
    var startTxt by remember { mutableStateOf("") }
    var preset by remember { mutableStateOf(0) }
    var cd by remember { mutableStateOf("45") }
    var cn by remember { mutableStateOf("3") }
    var zoom by remember { mutableStateOf(false) }
    var face by remember { mutableStateOf("auto") }
    var live by remember { mutableStateOf(false) }
    var divider by remember { mutableStateOf(true) }
    var formErr by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Session.busy) {
        if (Session.busy) act.window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else act.window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    val presets = listOf(Pair(30, 5), Pair(60, 5), Pair(15, 2))
    val d = if (preset < 3) presets[preset].first else (cd.toIntOrNull() ?: 0)
    val n = if (preset < 3) presets[preset].second else (cn.toIntOrNull() ?: 0)
    val st = try { Engine.parseTime(startTxt) ?: 0.0 } catch (e: Exception) { null }
    val summary = if (st == null) "Start time ka format galat hai (01:27:02 aisa likh)"
    else "$n clip x ${d}s = ${Engine.fmt((d * n).toDouble())} total  |  ${Engine.fmt(st)} se ${Engine.fmt(st + d * n)} tak"

    fun go() {
        formErr = null
        if (!Session.ready) { formErr = "Engine abhi start ho raha hai, 10 second ruk ke dobara dabaa."; return }
        if (url.isBlank()) { formErr = "YouTube link daal."; return }
        if (st == null) { formErr = "Start time ka format galat hai."; return }
        if (d < 5 || d > 180) { formErr = "Clip 5 se 180 second ke beech rakh."; return }
        if (n < 1 || n > 10) { formErr = "Clips 1 se 10 ke beech rakh."; return }
        Session.busy = true; Session.error = null; Session.logs.clear(); Session.clips.clear(); Session.progress = 1; Session.title = ""
        val p = Params(url.trim(), st, d, n, zoom, face, live, divider)
        val app = ctx.applicationContext
        thread { Engine.run(app, p) }
    }

    Column(
        Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF1A0838), BG))).statusBarsPadding()
            .verticalScroll(rememberScrollState()).padding(16.dp)
    ) {
        Text("CLIP KATARNAK", fontSize = 32.sp, fontWeight = FontWeight.ExtraBold, color = PINK)
        Text("YouTube video / live se 9:16 split-screen clips - gameplay upar, face neeche.", color = MUT, fontSize = 13.sp)
        Spacer(Modifier.height(14.dp))

        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(CARD).padding(16.dp)) {
            Label("YouTube link")
            OutlinedTextField(url, { url = it }, Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("https://youtube.com/watch?v=...") })
            Label("Start time (yaha se clip shuru)")
            OutlinedTextField(startTxt, { startTxt = it }, Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("01:27:02") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
            Text("Format HH:MM:SS (01:27:02), MM:SS, ya seconds.", color = MUT, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))

            Label("Kitni clip chahiye?")
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip("30s x 5", preset == 0, Modifier.weight(1f)) { preset = 0 }
                Chip("60s x 5", preset == 1, Modifier.weight(1f)) { preset = 1 }
                Chip("15s x 2", preset == 2, Modifier.weight(1f)) { preset = 2 }
                Chip("Custom", preset == 3, Modifier.weight(1f)) { preset = 3 }
            }
            if (preset == 3) {
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(cd, { cd = it }, Modifier.weight(1f), singleLine = true, label = { Text("Clip length (sec)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                    OutlinedTextField(cn, { cn = it }, Modifier.weight(1f), singleLine = true, label = { Text("Kitni clips") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                }
            }
            Text(summary, color = CYAN, fontSize = 13.sp, modifier = Modifier.padding(top = 10.dp))

            Label("Gameplay (upar wala half)")
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip("Poori screen + blur", !zoom, Modifier.weight(1f)) { zoom = false }
                Chip("Zoom (fill)", zoom, Modifier.weight(1f)) { zoom = true }
            }
            Label("Facecam position (neeche wala half)")
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip("Auto", face == "auto", Modifier.weight(1.2f)) { face = "auto" }
                Chip("Bot-Right", face == "br", Modifier.weight(1.4f)) { face = "br" }
                Chip("Bot-Left", face == "bl", Modifier.weight(1.4f)) { face = "bl" }
            }
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip("Top-Right", face == "tr", Modifier.weight(1f)) { face = "tr" }
                Chip("Top-Left", face == "tl", Modifier.weight(1f)) { face = "tl" }
                Chip("Center", face == "center", Modifier.weight(1f)) { face = "center" }
            }
            Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip(if (live) "Live stream: ON" else "Live stream: OFF", live, Modifier.weight(1f)) { live = !live }
                Chip(if (divider) "Divider: ON" else "Divider: OFF", divider, Modifier.weight(1f)) { divider = !divider }
            }
            formErr?.let { Text(it, color = Color(0xFFFF7A8A), fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp)) }
            Button(
                onClick = { go() }, enabled = !Session.busy,
                modifier = Modifier.fillMaxWidth().padding(top = 16.dp).height(58.dp),
                colors = ButtonDefaults.buttonColors(containerColor = PINK), shape = RoundedCornerShape(18.dp)
            ) { Text(if (Session.busy) "BAN RAHI HAIN..." else "CLIPS BANAO", fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, color = Color.White) }
            if (!Session.ready && Session.error == null) Text("Engine start ho raha hai...", color = MUT, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
        }

        if (Session.busy || Session.logs.isNotEmpty() || Session.error != null) {
            Spacer(Modifier.height(14.dp))
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(CARD).padding(16.dp)) {
                LinearProgressIndicator(progress = { Session.progress / 100f }, Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(99.dp)), color = PINK, trackColor = Color(0xFF0E0822))
                Text("${Session.progress}%  ${Session.title}", color = MUT, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
                Text(Session.logs.takeLast(8).joinToString("\n"), color = Color(0xFFCBBFF3), fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp))
                Session.error?.let { Text(it, color = Color(0xFFFF7A8A), fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp)) }
            }
        }

        if (Session.clips.isNotEmpty()) {
            Spacer(Modifier.height(14.dp))
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(CARD).padding(16.dp)) {
                Text("${Session.clips.size} clips ready", fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, color = Color.White)
                Text("Saved: ${Session.outDirName}", color = MUT, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp, bottom = 6.dp))
                for (c in Session.clips.toList()) {
                    Column(Modifier.fillMaxWidth().padding(top = 10.dp).clip(RoundedCornerShape(16.dp)).background(Color(0xFF0E0822)).padding(12.dp)) {
                        Text(c.label, color = Color.White, fontSize = 13.sp)
                        Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button({ openClip(ctx, c, false) }, Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = CYAN)) { Text("Play", color = Color.Black, fontWeight = FontWeight.Bold) }
                            Button({ openClip(ctx, c, true) }, Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = PINK)) { Text("Share / Save", color = Color.White, fontWeight = FontWeight.Bold) }
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(40.dp))
    }
}

fun openClip(ctx: android.content.Context, c: ClipOut, share: Boolean) {
    try {
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".provider", c.file)
        val i = if (share) Intent(Intent.ACTION_SEND).apply { type = "video/mp4"; putExtra(Intent.EXTRA_STREAM, uri) }
        else Intent(Intent.ACTION_VIEW).apply { setDataAndType(uri, "video/mp4") }
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(if (share) Intent.createChooser(i, "Clip bhejo / save karo") else i)
    } catch (e: Exception) { Session.log("Open error: " + (e.message ?: "")) }
}
