package com.clipkatarnak.app

import android.app.Application
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import kotlin.concurrent.thread

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        thread {
            try {
                YoutubeDL.getInstance().init(this)
                FFmpeg.getInstance().init(this)
                Session.ready = true
                Session.log("Engine ready")
            } catch (e: Exception) {
                Session.error = "Engine start nahi hua: " + (e.message ?: e.toString())
                Session.updating = false
                return@thread
            }
            Session.ytdlpVersion(this)?.let { Session.log("yt-dlp version: $it") }
            // yt-dlp ko latest karo (YouTube roz badalta hai)
            try {
                val y = YoutubeDL.getInstance()
                val m = y.javaClass.methods.filter { it.name == "updateYoutubeDL" }.minByOrNull { it.parameterCount }
                if (m != null) {
                    val args = m.parameterTypes.mapIndexed { i, t ->
                        if (i == 0) this as Any
                        else {
                            val c = t.enumConstants
                            (c?.firstOrNull { (it as Enum<*>).name == "NIGHTLY" } ?: c?.firstOrNull { (it as Enum<*>).name == "STABLE" } ?: c?.firstOrNull()) as Any
                        }
                    }
                    val r = m.invoke(y, *args.toTypedArray())
                    Session.log("yt-dlp update: " + r)
                    Session.ytdlpVersion(this)?.let { Session.log("yt-dlp ab: $it") }
                } else Session.log("yt-dlp update method nahi mila")
            } catch (e: Throwable) {
                val c = e.cause ?: e
                Session.log("yt-dlp update fail: " + (c.message ?: c.toString()).take(150))
            }
            Session.updating = false
        }
    }
}
