package com.clipkatarnak.app

import android.app.Application
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import kotlin.concurrent.thread

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        thread {
            try {
                YoutubeDL.getInstance().init(this)
                FFmpeg.getInstance().init(this)
                Session.ready = true
                Session.log("Engine ready")
            } catch (e: Exception) {
                Session.error = "Engine start nahi hua: " + (e.message ?: e.toString())
            }
            // yt-dlp ko latest karne ki koshish (YouTube roz badalta hai). Fail ho to koi baat nahi.
            try {
                val y = YoutubeDL.getInstance()
                val m = y.javaClass.methods.filter { it.name == "updateYoutubeDL" }.minByOrNull { it.parameterCount }
                if (m != null) {
                    val args = m.parameterTypes.mapIndexed { i, t ->
                        if (i == 0) this as Any
                        else (t.enumConstants?.firstOrNull { (it as Enum<*>).name == "STABLE" } ?: t.enumConstants?.firstOrNull()) as Any
                    }
                    m.invoke(y, *args.toTypedArray())
                    Session.log("yt-dlp update check done")
                }
            } catch (e: Throwable) { /* ignore */ }
        }
    }
}
