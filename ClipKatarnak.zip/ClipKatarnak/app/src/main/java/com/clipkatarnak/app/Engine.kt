package com.clipkatarnak.app

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.media.MediaScannerConnection
import android.os.Environment
import android.os.PowerManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateListOf
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Params(
    val url: String, val start: Double, val dur: Int, val count: Int,
    val zoom: Boolean, val face: String, val live: Boolean, val divider: Boolean
)

data class ClipOut(val file: File, val label: String)

object Session {
    var ready by mutableStateOf(false)
    var busy by mutableStateOf(false)
    var progress by mutableIntStateOf(0)
    var error by mutableStateOf<String?>(null)
    var title by mutableStateOf("")
    var outDirName by mutableStateOf("")
    var updating by mutableStateOf(true)
    @Volatile var cancel = false
    val logs = mutableStateListOf<String>()
    fun ytdlpVersion(ctx: Context): String? = try {
        val y = YoutubeDL.getInstance()
        val m = y.javaClass.methods.firstOrNull { it.name == "version" }
        m?.invoke(y, ctx)?.toString()
    } catch (e: Throwable) { null }
    val clips = mutableStateListOf<ClipOut>()
    fun log(m: String) { logs.add(m); if (logs.size > 200) logs.removeAt(0) }
}

object Engine {
    private const val ASPECT = 1.125

    // ---------------------------------------------------------------- helpers
    fun parseTime(s0: String): Double? {
        val s = s0.trim().trimStart('-', '–', '—', ' ').trim().lowercase()
        if (s.isEmpty()) return null
        if (Regex("""\d+(:\d+){1,2}(\.\d+)?""").matches(s)) {
            var sec = 0.0
            for (p in s.split(":")) sec = sec * 60 + p.toDouble()
            return sec
        }
        if (Regex("""\d+(\.\d+)?s?""").matches(s)) return s.trimEnd('s').toDouble()
        val m = Regex("""(?:(\d+)\s*h)?\s*(?:(\d+)\s*m)?\s*(?:(\d+)\s*s)?""").matchEntire(s)
        if (m != null && m.groupValues.drop(1).any { it.isNotEmpty() }) {
            val g = m.groupValues
            return (g[1].toIntOrNull() ?: 0) * 3600.0 + (g[2].toIntOrNull() ?: 0) * 60.0 + (g[3].toIntOrNull() ?: 0)
        }
        throw IllegalArgumentException("Time format galat hai. Aise likh: 01:27:02")
    }

    fun fmt(sec: Double): String {
        val s = Math.round(sec).toInt()
        return String.format(Locale.US, "%d:%02d:%02d", s / 3600, s % 3600 / 60, s % 60)
    }

    fun checkCancel() { if (Session.cancel) throw RuntimeException("Roka gaya (STOP dabaya)") }

    private fun clamp(v: Double, a: Double, b: Double) = maxOf(a, minOf(b, v))

    private fun fitRect(cx: Double, cy: Double, cw0: Double, ch0: Double, W: Int, H: Int): IntArray {
        val s = minOf(1.0, W / cw0, H / ch0)
        val cw = cw0 * s; val ch = ch0 * s
        val x = clamp(cx - cw / 2, 0.0, W - cw); val y = clamp(cy - ch / 2, 0.0, H - ch)
        return intArrayOf(x.toInt() / 2 * 2, y.toInt() / 2 * 2, cw.toInt() / 2 * 2, ch.toInt() / 2 * 2)
    }

    private fun faceCrop(f: DoubleArray, W: Int, H: Int): IntArray {
        val cw = f[2] * 2.6
        return fitRect(f[0] + f[2] / 2, f[1] + f[3] / 2 + f[3] * 0.08, cw, cw / ASPECT, W, H)
    }

    private val PRESETS = mapOf(
        "br" to doubleArrayOf(.68, .58, .32, .42), "bl" to doubleArrayOf(0.0, .58, .32, .42),
        "tr" to doubleArrayOf(.68, 0.0, .32, .42), "tl" to doubleArrayOf(0.0, 0.0, .32, .42),
        "center" to doubleArrayOf(.25, .1, .5, .8)
    )

    private fun presetCrop(name: String, W: Int, H: Int): IntArray {
        val p = PRESETS[name] ?: PRESETS["br"]!!
        var w = p[2] * W; var h = p[3] * H
        if (w / h < ASPECT) w = h * ASPECT else h = w / ASPECT
        return fitRect(p[0] * W + p[2] * W / 2, p[1] * H + p[3] * H / 2, w, h, W, H)
    }

    private fun median(v: List<Double>): Double { val s = v.sorted(); return s[s.size / 2] }

    // ---------------------------------------------------------------- face detection (ML Kit, on-device)
    private fun findFace(src: File, W: Int, H: Int, off: Double, durSec: Double): DoubleArray? {
        val det = FaceDetection.getClient(
            FaceDetectorOptions.Builder().setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST).build()
        )
        val r = MediaMetadataRetriever()
        val hits = mutableListOf<DoubleArray>()
        try {
            r.setDataSource(src.absolutePath)
            val n = 12
            for (k in 0 until n) {
                val us = ((off + durSec * (k + 0.5) / n) * 1_000_000).toLong()
                val bmp: Bitmap = r.getFrameAtTime(us, MediaMetadataRetriever.OPTION_CLOSEST_SYNC) ?: continue
                val sc = minOf(1.0, 960.0 / bmp.width)
                val small = if (sc < 1.0) Bitmap.createScaledBitmap(bmp, (bmp.width * sc).toInt(), (bmp.height * sc).toInt(), true) else bmp
                val faces = Tasks.await(det.process(InputImage.fromBitmap(small, 0)))
                for (f in faces) {
                    val b = f.boundingBox
                    if (b.width() / sc >= W * 0.025) hits.add(doubleArrayOf(b.left / sc, b.top / sc, b.width() / sc, b.height() / sc))
                }
            }
        } finally { try { r.release() } catch (_: Exception) {}; det.close() }
        if (hits.size < 2) return null
        val buckets = HashMap<Pair<Int, Int>, MutableList<DoubleArray>>()
        for (f in hits) {
            val key = Pair(((f[0] + f[2] / 2) / (W * .1)).toInt(), ((f[1] + f[3] / 2) / (H * .1)).toInt())
            buckets.getOrPut(key) { mutableListOf() }.add(f)
        }
        val best = buckets.values.maxByOrNull { v -> v.size * 100000 + v.sumOf { it[2] }.toInt() } ?: return null
        if (best.size < 2) return null
        return doubleArrayOf(median(best.map { it[0] }), median(best.map { it[1] }), median(best.map { it[2] }), median(best.map { it[3] }))
    }

    // ---------------------------------------------------------------- ffmpeg
    private var ffCache: File? = null

    private fun libPath(ctx: Context): String {
        val dirs = linkedSetOf<String>()
        dirs.add(ctx.applicationInfo.nativeLibraryDir)
        ctx.noBackupFilesDir.walkTopDown().filter { it.isFile && (it.name.endsWith(".so") || it.name.contains(".so.")) }
            .forEach { dirs.add(it.parentFile!!.absolutePath) }
        return dirs.joinToString(":")
    }

    private fun roots(ctx: Context) = listOf(File(ctx.applicationInfo.nativeLibraryDir), ctx.noBackupFilesDir, ctx.filesDir)

    private fun diag(ctx: Context): String =
        roots(ctx).flatMap { r -> r.walkTopDown().filter { it.isFile && (it.name.contains("ffmpeg", true) || it.name.startsWith("libav")) }.toList() }
            .take(8).joinToString { it.name }

    private fun ffmpegBin(ctx: Context): File? {
        ffCache?.let { if (it.exists()) return it }
        val cands = roots(ctx).flatMap { r ->
            r.walkTopDown().filter { it.isFile && (it.name == "libffmpeg.so" || it.name == "ffmpeg") }.toList()
        }
        for (f in cands) {
            f.setExecutable(true)
            val r = try { runFfmpeg(ctx, f, listOf("-version")) } catch (e: Exception) { Pair(false, e.toString()) }
            if (r.first) { ffCache = f; Session.log("ffmpeg mila: " + f.absolutePath.takeLast(50)); return f }
            else Session.log("ffmpeg try fail: " + r.second.take(120))
        }
        return null
    }

    private fun graph(zoom: Boolean, c: IntArray, divider: Boolean): String {
        val top = if (zoom)
            "[0:v]split=2[a][c];[a]crop='min(iw,ih*1.125)':'min(ih,iw/1.125)',scale=1080:960:flags=lanczos[top];"
        else
            "[0:v]split=3[a][b][c];" +
            "[a]scale=1080:960:force_original_aspect_ratio=increase,crop=1080:960,scale=216:192,gblur=sigma=8,scale=1080:960,eq=brightness=-0.18:saturation=1.25[bg];" +
            "[b]scale=1080:960:force_original_aspect_ratio=decrease[fg];[bg][fg]overlay=(W-w)/2:(H-h)/2[top];"
        return top + "[c]crop=${c[2]}:${c[3]}:${c[0]}:${c[1]},scale=1080:960:flags=lanczos[bot];[top][bot]vstack=inputs=2[s];" +
            "[s]" + (if (divider) "drawbox=x=0:y=956:w=1080:h=8:color=0xFF2E93:t=fill," else "") + "fps=30,setsar=1,format=yuv420p[v]"
    }

    private fun runFfmpeg(ctx: Context, bin: File, args: List<String>): Pair<Boolean, String> {
        val pb = ProcessBuilder(listOf(bin.absolutePath) + args).redirectErrorStream(true)
        pb.environment()["LD_LIBRARY_PATH"] = libPath(ctx)
        val p = pb.start()
        val out = p.inputStream.bufferedReader().readText()
        return Pair(p.waitFor() == 0, out)
    }

    private fun errText(e: Throwable): String {
        val s = e.message ?: e.toString()
        val lines = s.lines().map { it.trim() }.filter { it.isNotEmpty() }
        val errs = lines.filter { it.startsWith("ERROR") }.map { it.removePrefix("ERROR:").trim() }.filter { !it.startsWith("WARNING") && it.isNotEmpty() }
        val other = lines.filter { !it.startsWith("WARNING") && !it.startsWith("It is strongly") && !it.startsWith("Run \"yt-dlp") && !it.startsWith("To suppress") }
        return (errs.lastOrNull() ?: other.lastOrNull() ?: s).take(300)
    }

    private fun friendly(e: Throwable): String {
        val s = e.message ?: e.toString()
        return when {
            s.contains("Roka gaya") -> "Roka gaya."
            s.contains("JavaScript runtime", true) || s.contains("403") -> "YouTube ne download rok diya (" + errText(e) + "). App ko band karke dobara kholo (yt-dlp update hota hai) aur phir try karo."
            s.contains("Sign in to confirm") || s.contains("not a bot") ->
                "YouTube ne bot samajh ke roka. Thodi der baad dobara try kar, ya mobile data/WiFi badal ke dekh."
            s.contains("Private video") || s.contains("members-only", true) -> "Ye video private / members-only hai."
            s.contains("Video unavailable") -> "Video available nahi hai (link check kar)."
            else -> errText(e)
        }
    }

    // ---------------------------------------------------------------- helpers: network / diagnostics
    private fun details(e: Throwable): String {
        val s = e.message ?: e.toString()
        val lines = s.lines().map { it.trim() }.filter {
            it.isNotEmpty() && !it.startsWith("WARNING") && !it.startsWith("It is strongly") && !it.startsWith("Run \"yt-dlp") && !it.startsWith("To suppress")
        }
        return lines.takeLast(4).joinToString(" | ").take(350)
    }

    private var av1ok = false

    private fun selfTest(ctx: Context, bin: File) {
        try {
            val a = runFfmpeg(ctx, bin, listOf("-hide_banner", "-protocols")).second
            val b = runFfmpeg(ctx, bin, listOf("-hide_banner", "-encoders")).second
            val d = runFfmpeg(ctx, bin, listOf("-hide_banner", "-decoders")).second
            av1ok = d.contains("libdav1d") || d.contains("libaom")
            Session.log("ffmpeg test: https=" + (if (a.contains("https")) "yes" else "NO") + ", x264=" + b.contains("libx264") + ", aac=" + b.contains(" aac ") + ", av1=" + av1ok)
        } catch (e: Exception) { Session.log("ffmpeg test error: " + (e.message ?: "").take(80)) }
    }

    private fun httpGet(u: String, headers: Map<String, String>, tries: Int = 3): ByteArray {
        var last: Exception? = null
        for (i in 0 until tries) {
            try {
                val c = java.net.URL(u).openConnection() as java.net.HttpURLConnection
                c.connectTimeout = 15000; c.readTimeout = 30000; c.instanceFollowRedirects = true
                for ((k, v) in headers) if (!k.equals("Accept-Encoding", true)) c.setRequestProperty(k, v)
                val code = c.responseCode
                if (code >= 400) throw java.io.IOException("HTTP $code")
                return c.inputStream.use { it.readBytes() }
            } catch (e: Exception) { last = e; try { Thread.sleep(600) } catch (_: InterruptedException) {} }
        }
        throw last ?: RuntimeException("http fail")
    }

    private fun resolveUrl(base: String, ref: String): String = java.net.URL(java.net.URL(base), ref).toString()

    private fun clean(work: File) { work.listFiles()?.forEach { try { it.deleteRecursively() } catch (_: Exception) {} } }

    private fun findSrc(work: File): File? =
        work.listFiles()?.filter { it.isFile && it.name.startsWith("src.") && !it.name.endsWith(".part") && !it.name.endsWith(".ytdl") && it.length() > 1000 }
            ?.minByOrNull { if (it.extension == "mp4") 0 else 1 }

    private class HlsResult(val file: File, val off: Double, val w: Int, val h: Int, val dur: Double)

    /** Apna downloader: yt-dlp se sirf info lo, phir HLS ke zaroori segments khud download karo (ffmpeg ke network par depend nahi). */
    private fun hlsDownload(p: Params, client: String?, start: Double, end: Double, work: File): HlsResult {
        val req = YoutubeDLRequest(p.url)
        req.addOption("--skip-download"); req.addOption("--write-info-json"); req.addOption("--no-playlist")
        req.addOption("-o", File(work, "info").absolutePath)
        if (client != null) req.addOption("--extractor-args", "youtube:player_client=$client")
        YoutubeDL.getInstance().execute(req, "ck-info-" + (client ?: "def")) { _, _, _ -> }
        val jf = work.listFiles()?.firstOrNull { it.name.endsWith(".info.json") } ?: throw RuntimeException("info json nahi bani")
        val j = org.json.JSONObject(jf.readText()); jf.delete()
        val fm = j.getJSONArray("formats")
        var best: org.json.JSONObject? = null
        var nHls = 0
        for (i in 0 until fm.length()) {
            val f = fm.getJSONObject(i)
            if (!f.optString("protocol", "").startsWith("m3u8")) continue
            nHls++
            if (f.optString("vcodec", "none") == "none" || f.optString("acodec", "none") == "none") continue
            val h = f.optInt("height", 0)
            if (h > 1080) continue
            val b = best
            if (b == null || h > b.optInt("height", 0)) best = f
        }
        val f = best ?: throw RuntimeException("HLS muxed format nahi mila (hls formats: $nHls, total: ${fm.length()})")
        val headers = HashMap<String, String>()
        val hd = f.optJSONObject("http_headers") ?: j.optJSONObject("http_headers")
        if (hd != null) for (k in hd.keys()) headers[k] = hd.getString(k)
        var base = f.getString("url")
        var pl = String(httpGet(base, headers), Charsets.UTF_8)
        if (pl.contains("#EXT-X-STREAM-INF")) {
            val v = pl.lines().map { it.trim() }.first { it.isNotEmpty() && !it.startsWith("#") }
            base = resolveUrl(base, v); pl = String(httpGet(base, headers), Charsets.UTF_8)
        }
        var t = 0.0; var initUrl: String? = null; var pend = -1.0
        val segs = ArrayList<Triple<String, Double, Double>>()
        for (line in pl.lines()) {
            val l = line.trim()
            if (l.startsWith("#EXT-X-MAP:")) {
                val m = Regex("URI=\"([^\"]+)\"").find(l)
                if (m != null) initUrl = resolveUrl(base, m.groupValues[1])
            } else if (l.startsWith("#EXTINF:")) pend = l.removePrefix("#EXTINF:").substringBefore(",").toDoubleOrNull() ?: 0.0
            else if (l.isNotEmpty() && !l.startsWith("#") && pend >= 0) { segs.add(Triple(resolveUrl(base, l), t, pend)); t += pend; pend = -1.0 }
        }
        if (segs.isEmpty()) throw RuntimeException("playlist me segments nahi mile")
        val sel = segs.filter { it.second < end && it.second + it.third > start }
        if (sel.isEmpty()) throw RuntimeException("Start time playlist ke bahar hai (playlist ${fmt(t)} tak ki hai)")
        Session.log("HLS (${client ?: "default"}): ${sel.size} segments, ${f.optInt("height")}p")
        val out = File(work, if (initUrl != null) "src_hls.mp4" else "src_hls.ts")
        java.io.FileOutputStream(out).use { os ->
            initUrl?.let { os.write(httpGet(it, headers)) }
            for ((k, sg) in sel.withIndex()) {
                checkCancel()
                os.write(httpGet(sg.first, headers))
                Session.progress = maxOf(Session.progress, 8 + (40 * (k + 1) / sel.size))
            }
        }
        val first = sel.first(); val last = sel.last()
        return HlsResult(out, start - first.second, f.optInt("width", 0), f.optInt("height", 0), last.second + last.third - first.second - (start - first.second))
    }


    // ---------------------------------------------------------------- DASH range downloader (chunked, 403 se bachne ke liye)
    private fun getBytes(u: String, headers: Map<String, String>, range: String?): ByteArray {
        val c = java.net.URL(u).openConnection() as java.net.HttpURLConnection
        c.connectTimeout = 15000; c.readTimeout = 40000; c.instanceFollowRedirects = true
        for ((k, v) in headers) if (!k.equals("Accept-Encoding", true) && !k.equals("Range", true)) c.setRequestProperty(k, v)
        if (range != null) c.setRequestProperty("Range", range)
        val code = c.responseCode
        if (code != 200 && code != 206) throw java.io.IOException("HTTP $code")
        return c.inputStream.use { it.readBytes() }
    }

    /** Bounded range request. Header se 403 mile to YouTube ka &range= query tareeka bhi try karta hai. */
    private fun rangeGet(u: String, headers: Map<String, String>, a: Long, b: Long): ByteArray {
        var last: Exception? = null
        for (i in 0 until 3) {
            checkCancel()
            try { return getBytes(u, headers, "bytes=$a-$b") }
            catch (e: Exception) {
                last = e
                if ((e.message ?: "").contains("403")) {
                    try { return getBytes(u + (if (u.contains("?")) "&" else "?") + "range=$a-$b", headers, null) }
                    catch (e2: Exception) { last = e2 }
                }
                try { Thread.sleep(700) } catch (_: InterruptedException) {}
            }
        }
        throw RuntimeException("(bytes $a-$b) " + (last?.message ?: "range fail"))
    }

    private class Sidx(val start: Int, val end: Long, val timescale: Long, val earliest: Long, val firstOffset: Long,
                       val sizes: LongArray, val durs: LongArray)

    private fun u32(bb: java.nio.ByteBuffer, p: Int): Long = bb.getInt(p).toLong() and 0xFFFFFFFFL

    private fun parseSidx(b: ByteArray): Sidx? {
        val bb = java.nio.ByteBuffer.wrap(b)
        var pos = 0
        while (pos + 8 <= b.size) {
            var size = u32(bb, pos)
            val type = String(b, pos + 4, 4, Charsets.ISO_8859_1)
            var hdr = 8
            if (size == 1L) { if (pos + 16 > b.size) return null; size = bb.getLong(pos + 8); hdr = 16 }
            if (size < hdr || pos + size > b.size) return null
            if (type == "sidx") {
                var p = pos + hdr
                val ver = b[p].toInt(); p += 4
                p += 4
                val ts = u32(bb, p); p += 4
                val earliest: Long; val first: Long
                if (ver == 0) { earliest = u32(bb, p); first = u32(bb, p + 4); p += 8 }
                else { earliest = bb.getLong(p); first = bb.getLong(p + 8); p += 16 }
                p += 2
                val cnt = bb.getShort(p).toInt() and 0xFFFF; p += 2
                val sizes = LongArray(cnt); val durs = LongArray(cnt)
                for (i in 0 until cnt) {
                    sizes[i] = u32(bb, p) and 0x7FFFFFFFL
                    durs[i] = u32(bb, p + 4)
                    p += 12
                }
                return Sidx(pos, pos + size, ts, earliest, first, sizes, durs)
            }
            pos += size.toInt()
        }
        return null
    }

    private class Dash(val off: Double, val dur: Double)

    private fun dashStream(f: org.json.JSONObject, headers: Map<String, String>, start: Double, end: Double, out: File, pBase: Int, pSpan: Int): Dash {
        val url = f.getString("url")
        val size = f.optLong("filesize", f.optLong("filesize_approx", 0L))
        var fetchLen = 600_000L
        var buf = ByteArray(0)
        var sd: Sidx? = null
        for (attempt in 0 until 3) {
            val bEnd = if (size > 0) minOf(fetchLen - 1, size - 1) else fetchLen - 1
            buf = rangeGet(url, headers, 0, bEnd)
            sd = parseSidx(buf)
            if (sd != null || buf.size < fetchLen) break
            fetchLen *= 4
        }
        val sx = sd ?: throw RuntimeException("sidx (index) nahi mila is format me")
        val ts = sx.timescale.toDouble()
        var t = sx.earliest / ts
        var byteOff = sx.end + sx.firstOffset
        var firstStart = 0.0; var firstByte = -1L; var endByte = 0L; var lastEnd = 0.0
        for (i in sx.sizes.indices) {
            val d = sx.durs[i] / ts
            if (t < end && t + d > start) {
                if (firstByte < 0) { firstStart = t; firstByte = byteOff }
                endByte = byteOff + sx.sizes[i]; lastEnd = t + d
            }
            t += d; byteOff += sx.sizes[i]
        }
        if (firstByte < 0) throw RuntimeException("Start time is stream ke andar nahi hai (stream ${fmt(t)} tak)")
        java.io.FileOutputStream(out).use { os ->
            os.write(buf, 0, sx.start)                // ftyp + moov
            var pos = firstByte
            val chunk = 8L * 1024 * 1024
            while (pos < endByte) {
                val e = minOf(pos + chunk - 1, endByte - 1)
                os.write(rangeGet(url, headers, pos, e))
                pos = e + 1
                Session.progress = maxOf(Session.progress, pBase + (pSpan * (pos - firstByte) / (endByte - firstByte)).toInt())
            }
        }
        return Dash(start - firstStart, lastEnd - start)
    }

    private fun fetchInfo(p: Params, client: String?, work: File): org.json.JSONObject {
        val req = YoutubeDLRequest(p.url)
        req.addOption("--skip-download"); req.addOption("--write-info-json"); req.addOption("--no-playlist")
        req.addOption("-o", File(work, "info").absolutePath)
        if (client != null) req.addOption("--extractor-args", "youtube:player_client=$client")
        YoutubeDL.getInstance().execute(req, "ck-info-" + (client ?: "def")) { _, _, _ -> }
        val jf = work.listFiles()?.firstOrNull { it.name.endsWith(".info.json") } ?: throw RuntimeException("info json nahi bani")
        val j = org.json.JSONObject(jf.readText()); jf.delete(); return j
    }

    private class DashRes(val v: File, val vOff: Double, val a: File, val aOff: Double, val w: Int, val h: Int, val dur: Double)

    private fun dashDownload(p: Params, client: String?, start: Double, end: Double, work: File): DashRes {
        val j = fetchInfo(p, client, work)
        val fm = j.getJSONArray("formats")
        var bv: org.json.JSONObject? = null; var ba: org.json.JSONObject? = null
        val seen = HashSet<String>()
        for (i in 0 until fm.length()) {
            val f = fm.getJSONObject(i)
            if (!f.optString("url", "").startsWith("http") || f.optString("protocol", "") != "https") continue
            val vc = f.optString("vcodec", "none"); val ac = f.optString("acodec", "none"); val ext = f.optString("ext", "")
            if (vc != "none" && ac == "none" && ext == "mp4") {
                seen.add(vc.take(4))
                val avc = vc.startsWith("avc1"); val av1 = vc.startsWith("av01") && av1ok
                val h = f.optInt("height", 0)
                if ((!avc && !av1) || h > 1080) continue
                val sc = (if (avc) 100000 else 0) + h
                val cur = bv
                if (cur == null || sc > ((if (cur.optString("vcodec").startsWith("avc1")) 100000 else 0) + cur.optInt("height", 0))) bv = f
            } else if (vc == "none" && ac.startsWith("mp4a") && ext == "m4a") {
                val cur = ba
                if (cur == null || f.optDouble("abr", 0.0) > cur.optDouble("abr", 0.0)) ba = f
            }
        }
        val v = bv ?: throw RuntimeException("mp4 video format nahi mila (codecs: $seen, formats: ${fm.length()})")
        val a = ba ?: throw RuntimeException("m4a audio format nahi mila")
        Session.log("DASH (${client ?: "default"}): v=${v.optString("format_id")} ${v.optInt("height")}p ${v.optString("vcodec").take(4)}, a=${a.optString("format_id")}")
        val vh = HashMap<String, String>(); val ah = HashMap<String, String>()
        val h1 = v.optJSONObject("http_headers") ?: j.optJSONObject("http_headers")
        if (h1 != null) for (k in h1.keys()) vh[k] = h1.getString(k)
        val h2 = a.optJSONObject("http_headers") ?: j.optJSONObject("http_headers")
        if (h2 != null) for (k in h2.keys()) ah[k] = h2.getString(k)
        val vf = File(work, "dash_v.mp4"); val af = File(work, "dash_a.m4a")
        val vr = dashStream(v, vh, start, end, vf, 8, 32)
        val ar = dashStream(a, ah, start, end, af, 40, 8)
        return DashRes(vf, vr.off, af, ar.off, v.optInt("width", 0), v.optInt("height", 0), minOf(vr.dur, ar.dur))
    }

    // ---------------------------------------------------------------- main pipeline
    fun run(ctx: Context, p: Params) {
        val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
        val wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ck:job")
        wl.acquire(90 * 60 * 1000L)
        val work = File(ctx.getExternalFilesDir(null) ?: ctx.cacheDir, "work").apply { deleteRecursively(); mkdirs() }
        try {
            Session.progress = 2
            val bin = ffmpegBin(ctx) ?: throw RuntimeException("ffmpeg engine nahi mila. Files: " + diag(ctx))
            selfTest(ctx, bin)
            val freeMb = work.usableSpace / 1048576
            if (freeMb < 300) throw RuntimeException("Phone me jagah bahut kam hai ($freeMb MB). Kuch delete karke dobara try kar.")
            if (freeMb < 800) Session.log("Dhyan: phone me sirf $freeMb MB jagah bachi hai")
            var n = p.count
            var end = p.start + p.dur * n

            try {
                Session.log("Video ki info la raha hu...")
                val info = YoutubeDL.getInstance().getInfo(p.url)
                Session.title = info.title ?: ""
                val len = info.duration.toString().toDoubleOrNull()
                if (len != null && len > 0 && !p.live) {
                    if (p.start >= len) throw IllegalArgumentException("Start time (${fmt(p.start)}) video ki length (${fmt(len)}) se zyada hai.")
                    if (end > len) {
                        n = ((len - p.start) / p.dur + 0.05).toInt()
                        if (n < 1) throw IllegalArgumentException("Start ke baad itna video bacha hi nahi.")
                        Session.log("Video ${fmt(len)} pe khatam hoti hai, isliye $n clip banengi")
                        end = p.start + p.dur * n
                    }
                }
            } catch (e: IllegalArgumentException) { throw e }
            catch (e: Exception) { Session.log("Info nahi mili: " + details(e)) }

            Session.progress = 8
            Session.log("Download: ${fmt(p.start)} -> ${fmt(end)}")
            var w = 0
            if (Session.updating) Session.log("yt-dlp update ho raha hai, thoda ruk...")
            while (Session.updating && w < 90) { checkCancel(); Thread.sleep(1000); w++ }
            Session.ytdlpVersion(ctx)?.let { Session.log("yt-dlp version: $it") }

            fun buildReq(client: String?): YoutubeDLRequest {
                val req = YoutubeDLRequest(p.url)
                req.addOption("--no-playlist")
                req.addOption("--download-sections", "*${fmt(p.start)}-${fmt(end)}")
                req.addOption("--force-keyframes-at-cuts")
                req.addOption("-f", "bv*[height<=1080]+ba/b[height<=1080]/b")
                req.addOption("--merge-output-format", "mp4")
                req.addOption("-o", File(work, "src.%(ext)s").absolutePath)
                if (p.live) req.addOption("--live-from-start")
                if (client != null) req.addOption("--extractor-args", "youtube:player_client=$client")
                return req
            }
            fun dl(req: YoutubeDLRequest, id: String) {
                YoutubeDL.getInstance().execute(req, id) { prog, _, _ ->
                    if (prog > 0) Session.progress = maxOf(Session.progress, (8 + 40 * prog / 100f).toInt())
                }
            }

            var src: File? = null; var srcOff = 0.0; var W = 0; var H = 0; var actual = 0.0
            var audioSrc: File? = null; var audioOff = 0.0

            // tareeka A: apna chunked DASH downloader (403 wali problem ka asli ilaaj)
            Session.log("Tareeka A: chunked downloader...")
            for (c in listOf<String?>("android_vr", null, "tv")) {
                try {
                    val r = dashDownload(p, c, p.start, end, work)
                    src = r.v; srcOff = r.vOff; audioSrc = r.a; audioOff = r.aOff; W = r.w; H = r.h; actual = r.dur
                    break
                } catch (e: Exception) { Session.log("A fail (${c ?: "default"}): " + details(e)); clean(work) }
            }
            // tareeka 1: yt-dlp ka --download-sections (ffmpeg se)
            if (src == null) for (c in listOf<String?>(null, "android_vr")) {
                try {
                    Session.log("Tareeka 1 (" + (c ?: "default") + ")...")
                    dl(buildReq(c), "ck-" + (c ?: "def"))
                    src = findSrc(work)
                    if (src != null) break
                } catch (e: Exception) { Session.log("Fail: " + details(e)); clean(work) }
            }
            // tareeka 2: apna HLS downloader
            if (src == null) {
                Session.log("Tareeka 2: apna downloader (HLS)...")
                for (c in listOf<String?>(null, "web_safari", "ios", "tv")) {
                    try {
                        val r = hlsDownload(p, c, p.start, end, work)
                        src = r.file; srcOff = r.off; W = r.w; H = r.h; actual = r.dur
                        break
                    } catch (e: Exception) { Session.log("HLS fail (${c ?: "default"}): " + details(e)); clean(work) }
                }
            }
            if (src == null) throw RuntimeException("Download kisi bhi tareeke se nahi hua. 'Logs copy karo' dabake mujhe bhej de.")

            if (W == 0 || H == 0 || actual <= 0.0) {
                val mr = MediaMetadataRetriever(); mr.setDataSource(src.absolutePath)
                W = mr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)!!.toInt()
                H = mr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)!!.toInt()
                val rot = mr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
                if (rot % 180 != 0) { val t = W; W = H; H = t }
                if (actual <= 0.0) actual = (mr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toDoubleOrNull() ?: 0.0) / 1000.0 - srcOff
                mr.release()
            }
            Session.progress = 52; Session.log("Source ${W}x$H, ${fmt(actual)}")
            n = minOf(n, ((actual + 1.5) / p.dur).toInt())
            if (n < 1) throw RuntimeException("Itne time ka video mila hi nahi.")

            val crop: IntArray
            if (p.face == "auto") {
                Session.log("Face dhoond raha hu...")
                val face = try { findFace(src, W, H, srcOff, minOf(actual, 600.0)) } catch (e: Throwable) { Session.log("Face detect error: " + (e.message ?: "").take(80)); null }
                if (face != null) { Session.log("Face mil gaya"); crop = faceCrop(face, W, H) }
                else { Session.log("Face nahi mila - bottom-right corner maan raha hu"); crop = presetCrop("br", W, H) }
            } else crop = presetCrop(p.face, W, H)
            Session.progress = 58

            var outDir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "ClipKatarnak")
            val okDir = try { outDir.mkdirs(); outDir.canWrite() } catch (e: Exception) { false }
            if (!okDir) outDir = File(ctx.getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: ctx.filesDir, "clips").apply { mkdirs() }
            Session.outDirName = outDir.absolutePath
            val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

            val g = graph(p.zoom, crop, p.divider)
            for (i in 0 until n) {
                checkCancel()
                val rel = i * p.dur.toDouble()
                val out = File(outDir, "Clip_${stamp}_%02d.mp4".format(Locale.US, i + 1))
                Session.log("Clip ${i + 1}/$n bana raha hu (${fmt(p.start + i * p.dur.toDouble())})")
                val ins = ArrayList<String>(listOf("-ss", String.format(Locale.US, "%.3f", srcOff + rel), "-t", p.dur.toString(), "-i", src.absolutePath))
                val asrc = audioSrc
                if (asrc != null) ins.addAll(listOf("-ss", String.format(Locale.US, "%.3f", audioOff + rel), "-t", p.dur.toString(), "-i", asrc.absolutePath))
                val common = listOf("-y", "-v", "error") + ins + listOf("-filter_complex", g, "-map", "[v]", "-map", if (asrc != null) "1:a" else "0:a?")
                val tail = listOf("-c:a", "aac", "-b:a", "160k", "-movflags", "+faststart", "-t", p.dur.toString(), out.absolutePath)
                var res = runFfmpeg(ctx, bin, common + listOf("-c:v", "libx264", "-preset", "ultrafast", "-crf", "23") + tail)
                if (!res.first) res = runFfmpeg(ctx, bin, common + listOf("-c:v", "mpeg4", "-q:v", "3") + tail)
                if (!res.first || !out.exists()) throw RuntimeException("ffmpeg error: " + res.second.takeLast(300))
                MediaScannerConnection.scanFile(ctx, arrayOf(out.absolutePath), arrayOf("video/mp4"), null)
                val cs = p.start + i * p.dur.toDouble()
                Session.clips.add(ClipOut(out, "Clip ${i + 1}  |  ${fmt(cs)} - ${fmt(cs + p.dur)}  |  ${p.dur}s"))
                Session.progress = 58 + (40 * (i + 1) / n)
            }
            Session.progress = 100; Session.log("Ho gaya! $n clip ready")
        } catch (e: Throwable) {
            e.printStackTrace(); Session.error = friendly(e); Session.log("ERROR: " + Session.error)
        } finally {
            try { work.deleteRecursively() } catch (_: Exception) {}
            if (wl.isHeld) wl.release()
            Session.busy = false
        }
    }
}
