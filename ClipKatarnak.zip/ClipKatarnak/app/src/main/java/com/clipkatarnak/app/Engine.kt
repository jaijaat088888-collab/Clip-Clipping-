package com.clipkatarnak.app

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.media.MediaScannerConnection
import android.os.Environment
import android.os.PowerManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateListOf
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Params(
    val url: String, val start: Double, val dur: Int, val count: Int,
    val zoom: Boolean, val face: String, val live: Boolean, val divider: Boolean
)

data class ClipOut(val file: File, val label: String)

object Session {
    var ready by mutableStateOf(false)
    var busy by mutableStateOf(false)
    var progress by mutableIntStateOf(0)
    var error by mutableStateOf<String?>(null)
    var title by mutableStateOf("")
    var outDirName by mutableStateOf("")
    val logs = mutableStateListOf<String>()
    val clips = mutableStateListOf<ClipOut>()
    fun log(m: String) { logs.add(m); if (logs.size > 60) logs.removeAt(0) }
}

object Engine {
    private const val ASPECT = 1.125

    // ---------------------------------------------------------------- helpers
    fun parseTime(s0: String): Double? {
        val s = s0.trim().trimStart('-', '–', '—', ' ').trim().lowercase()
        if (s.isEmpty()) return null
        if (Regex("""\d+(:\d+){1,2}(\.\d+)?""").matches(s)) {
            var sec = 0.0
            for (p in s.split(":")) sec = sec * 60 + p.toDouble()
            return sec
        }
        if (Regex("""\d+(\.\d+)?s?""").matches(s)) return s.trimEnd('s').toDouble()
        val m = Regex("""(?:(\d+)\s*h)?\s*(?:(\d+)\s*m)?\s*(?:(\d+)\s*s)?""").matchEntire(s)
        if (m != null && m.groupValues.drop(1).any { it.isNotEmpty() }) {
            val g = m.groupValues
            return (g[1].toIntOrNull() ?: 0) * 3600.0 + (g[2].toIntOrNull() ?: 0) * 60.0 + (g[3].toIntOrNull() ?: 0)
        }
        throw IllegalArgumentException("Time format galat hai. Aise likh: 01:27:02")
    }

    fun fmt(sec: Double): String {
        val s = Math.round(sec).toInt()
        return String.format(Locale.US, "%d:%02d:%02d", s / 3600, s % 3600 / 60, s % 60)
    }

    private fun clamp(v: Double, a: Double, b: Double) = maxOf(a, minOf(b, v))

    private fun fitRect(cx: Double, cy: Double, cw0: Double, ch0: Double, W: Int, H: Int): IntArray {
        val s = minOf(1.0, W / cw0, H / ch0)
        val cw = cw0 * s; val ch = ch0 * s
        val x = clamp(cx - cw / 2, 0.0, W - cw); val y = clamp(cy - ch / 2, 0.0, H - ch)
        return intArrayOf(x.toInt() / 2 * 2, y.toInt() / 2 * 2, cw.toInt() / 2 * 2, ch.toInt() / 2 * 2)
    }

    private fun faceCrop(f: DoubleArray, W: Int, H: Int): IntArray {
        val cw = f[2] * 2.6
        return fitRect(f[0] + f[2] / 2, f[1] + f[3] / 2 + f[3] * 0.08, cw, cw / ASPECT, W, H)
    }

    private val PRESETS = mapOf(
        "br" to doubleArrayOf(.68, .58, .32, .42), "bl" to doubleArrayOf(0.0, .58, .32, .42),
        "tr" to doubleArrayOf(.68, 0.0, .32, .42), "tl" to doubleArrayOf(0.0, 0.0, .32, .42),
        "center" to doubleArrayOf(.25, .1, .5, .8)
    )

    private fun presetCrop(name: String, W: Int, H: Int): IntArray {
        val p = PRESETS[name] ?: PRESETS["br"]!!
        var w = p[2] * W; var h = p[3] * H
        if (w / h < ASPECT) w = h * ASPECT else h = w / ASPECT
        return fitRect(p[0] * W + p[2] * W / 2, p[1] * H + p[3] * H / 2, w, h, W, H)
    }

    private fun median(v: List<Double>): Double { val s = v.sorted(); return s[s.size / 2] }

    // ---------------------------------------------------------------- face detection (ML Kit, on-device)
    private fun findFace(src: File, W: Int, H: Int, durSec: Double): DoubleArray? {
        val det = FaceDetection.getClient(
            FaceDetectorOptions.Builder().setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST).build()
        )
        val r = MediaMetadataRetriever()
        val hits = mutableListOf<DoubleArray>()
        try {
            r.setDataSource(src.absolutePath)
            val n = 12
            for (k in 0 until n) {
                val us = (durSec * (k + 0.5) / n * 1_000_000).toLong()
                val bmp: Bitmap = r.getFrameAtTime(us, MediaMetadataRetriever.OPTION_CLOSEST_SYNC) ?: continue
                val sc = minOf(1.0, 960.0 / bmp.width)
                val small = if (sc < 1.0) Bitmap.createScaledBitmap(bmp, (bmp.width * sc).toInt(), (bmp.height * sc).toInt(), true) else bmp
                val faces = Tasks.await(det.process(InputImage.fromBitmap(small, 0)))
                for (f in faces) {
                    val b = f.boundingBox
                    if (b.width() / sc >= W * 0.025) hits.add(doubleArrayOf(b.left / sc, b.top / sc, b.width() / sc, b.height() / sc))
                }
            }
        } finally { try { r.release() } catch (_: Exception) {}; det.close() }
        if (hits.size < 2) return null
        val buckets = HashMap<Pair<Int, Int>, MutableList<DoubleArray>>()
        for (f in hits) {
            val key = Pair(((f[0] + f[2] / 2) / (W * .1)).toInt(), ((f[1] + f[3] / 2) / (H * .1)).toInt())
            buckets.getOrPut(key) { mutableListOf() }.add(f)
        }
        val best = buckets.values.maxByOrNull { v -> v.size * 100000 + v.sumOf { it[2] }.toInt() } ?: return null
        if (best.size < 2) return null
        return doubleArrayOf(median(best.map { it[0] }), median(best.map { it[1] }), median(best.map { it[2] }), median(best.map { it[3] }))
    }

    // ---------------------------------------------------------------- ffmpeg
    private fun ffmpegBin(ctx: Context): File? {
        for (root in listOf(ctx.noBackupFilesDir, ctx.filesDir, ctx.codeCacheDir)) {
            val f = root.walkTopDown().firstOrNull { it.isFile && it.name == "libffmpeg.so" }
            if (f != null) { f.setExecutable(true); return f }
        }
        return null
    }

    private fun graph(zoom: Boolean, c: IntArray, divider: Boolean): String {
        val top = if (zoom)
            "[0:v]split=2[a][c];[a]crop='min(iw,ih*1.125)':'min(ih,iw/1.125)',scale=1080:960:flags=lanczos[top];"
        else
            "[0:v]split=3[a][b][c];" +
            "[a]scale=1080:960:force_original_aspect_ratio=increase,crop=1080:960,scale=216:192,gblur=sigma=8,scale=1080:960,eq=brightness=-0.18:saturation=1.25[bg];" +
            "[b]scale=1080:960:force_original_aspect_ratio=decrease[fg];[bg][fg]overlay=(W-w)/2:(H-h)/2[top];"
        return top + "[c]crop=${c[2]}:${c[3]}:${c[0]}:${c[1]},scale=1080:960:flags=lanczos[bot];[top][bot]vstack=inputs=2[s];" +
            "[s]" + (if (divider) "drawbox=x=0:y=956:w=1080:h=8:color=0xFF2E93:t=fill," else "") + "fps=30,setsar=1,format=yuv420p[v]"
    }

    private fun runFfmpeg(bin: File, args: List<String>): Pair<Boolean, String> {
        val pb = ProcessBuilder(listOf(bin.absolutePath) + args).redirectErrorStream(true)
        pb.environment()["LD_LIBRARY_PATH"] = bin.parentFile!!.absolutePath
        val p = pb.start()
        val out = p.inputStream.bufferedReader().readText()
        return Pair(p.waitFor() == 0, out)
    }

    private fun friendly(e: Throwable): String {
        val s = e.message ?: e.toString()
        return when {
            s.contains("Sign in to confirm") || s.contains("not a bot") ->
                "YouTube ne bot samajh ke roka. Thodi der baad dobara try kar, ya mobile data/WiFi badal ke dekh."
            s.contains("Private video") || s.contains("members-only", true) -> "Ye video private / members-only hai."
            s.contains("Video unavailable") -> "Video available nahi hai (link check kar)."
            else -> s.take(300)
        }
    }

    // ---------------------------------------------------------------- main pipeline
    fun run(ctx: Context, p: Params) {
        val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
        val wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ck:job")
        wl.acquire(90 * 60 * 1000L)
        val work = File(ctx.getExternalFilesDir(null) ?: ctx.cacheDir, "work").apply { deleteRecursively(); mkdirs() }
        try {
            Session.progress = 2
            val bin = ffmpegBin(ctx) ?: throw RuntimeException("ffmpeg engine nahi mila (app dobara kholke try kar)")
            var n = p.count
            var end = p.start + p.dur * n

            try {
                Session.log("Video ki info la raha hu...")
                val info = YoutubeDL.getInstance().getInfo(p.url)
                Session.title = info.title ?: ""
                val len = info.duration.toString().toDoubleOrNull()
                if (len != null && len > 0 && !p.live) {
                    if (p.start >= len) throw IllegalArgumentException("Start time (${fmt(p.start)}) video ki length (${fmt(len)}) se zyada hai.")
                    if (end > len) {
                        n = ((len - p.start) / p.dur + 0.05).toInt()
                        if (n < 1) throw IllegalArgumentException("Start ke baad itna video bacha hi nahi.")
                        Session.log("Video ${fmt(len)} pe khatam hoti hai, isliye $n clip banengi")
                        end = p.start + p.dur * n
                    }
                }
            } catch (e: IllegalArgumentException) { throw e }
            catch (e: Exception) { Session.log("Info nahi mili, seedha download try karta hu"); if ((e.message ?: "").contains("Sign in")) throw e }

            Session.progress = 8
            Session.log("Download: ${fmt(p.start)} -> ${fmt(end)}")
            val req = YoutubeDLRequest(p.url)
            req.addOption("--no-playlist")
            req.addOption("--download-sections", "*${fmt(p.start)}-${fmt(end)}")
            req.addOption("--force-keyframes-at-cuts")
            req.addOption("-f", "bv*[height<=1080]+ba/b[height<=1080]/b")
            req.addOption("--merge-output-format", "mp4")
            req.addOption("-o", File(work, "src.%(ext)s").absolutePath)
            if (p.live) req.addOption("--live-from-start")
            YoutubeDL.getInstance().execute(req, "ck-job") { prog, _, _ ->
                if (prog > 0) Session.progress = maxOf(Session.progress, (8 + 40 * prog / 100f).toInt())
            }
            val src = work.listFiles()?.filter { it.isFile && it.name.startsWith("src.") && !it.name.endsWith(".part") && !it.name.endsWith(".ytdl") }
                ?.minByOrNull { if (it.extension == "mp4") 0 else 1 } ?: throw RuntimeException("Download fail ho gaya (file nahi bani).")

            val mr = MediaMetadataRetriever(); mr.setDataSource(src.absolutePath)
            var W = mr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)!!.toInt()
            var H = mr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)!!.toInt()
            val rot = mr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            if (rot % 180 != 0) { val t = W; W = H; H = t }
            val actual = (mr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)!!.toDouble()) / 1000.0
            mr.release()
            Session.progress = 52; Session.log("Source ${W}x$H, ${fmt(actual)}")
            n = minOf(n, ((actual + 1.5) / p.dur).toInt())
            if (n < 1) throw RuntimeException("Itne time ka video mila hi nahi.")

            // facecam
            val crop: IntArray
            if (p.face == "auto") {
                Session.log("Face dhoond raha hu...")
                val face = try { findFace(src, W, H, minOf(actual, 600.0)) } catch (e: Throwable) { Session.log("Face detect error: " + (e.message ?: "").take(80)); null }
                if (face != null) { Session.log("Face mil gaya"); crop = faceCrop(face, W, H) }
                else { Session.log("Face nahi mila - bottom-right corner maan raha hu"); crop = presetCrop("br", W, H) }
            } else crop = presetCrop(p.face, W, H)
            Session.progress = 58

            // output folder
            var outDir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "ClipKatarnak")
            val okDir = try { outDir.mkdirs(); outDir.canWrite() } catch (e: Exception) { false }
            if (!okDir) outDir = File(ctx.getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: ctx.filesDir, "clips").apply { mkdirs() }
            Session.outDirName = outDir.absolutePath
            val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

            val g = graph(p.zoom, crop, p.divider)
            for (i in 0 until n) {
                val t0 = i * p.dur.toDouble()
                val out = File(outDir, "Clip_${stamp}_%02d.mp4".format(Locale.US, i + 1))
                Session.log("Clip ${i + 1}/$n bana raha hu (${fmt(p.start + t0)})")
                val common = listOf("-y", "-v", "error", "-ss", String.format(Locale.US, "%.3f", t0), "-t", p.dur.toString(), "-i", src.absolutePath,
                    "-filter_complex", g, "-map", "[v]", "-map", "0:a?")
                val tail = listOf("-c:a", "aac", "-b:a", "160k", "-movflags", "+faststart", "-t", p.dur.toString(), out.absolutePath)
                var res = runFfmpeg(bin, common + listOf("-c:v", "libx264", "-preset", "ultrafast", "-crf", "23") + tail)
                if (!res.first) res = runFfmpeg(bin, common + listOf("-c:v", "mpeg4", "-q:v", "3") + tail)   // x264 na ho to mpeg4
                if (!res.first || !out.exists()) throw RuntimeException("ffmpeg error: " + res.second.takeLast(300))
                MediaScannerConnection.scanFile(ctx, arrayOf(out.absolutePath), arrayOf("video/mp4"), null)
                Session.clips.add(ClipOut(out, "Clip ${i + 1}  |  ${fmt(p.start + t0)} - ${fmt(p.start + t0 + p.dur)}  |  ${p.dur}s"))
                Session.progress = 58 + (40 * (i + 1) / n)
            }
            Session.progress = 100; Session.log("Ho gaya! $n clip ready")
        } catch (e: Throwable) {
            e.printStackTrace(); Session.error = friendly(e); Session.log("ERROR: " + Session.error)
        } finally {
            try { work.deleteRecursively() } catch (_: Exception) {}
            if (wl.isHeld) wl.release()
            Session.busy = false
        }
    }
}
