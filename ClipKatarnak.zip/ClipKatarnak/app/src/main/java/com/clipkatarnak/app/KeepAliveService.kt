package com.clipkatarnak.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder

/** Clips banate waqt app ko background me band hone se bachata hai. */
class KeepAliveService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val ch = "ck_job"
        val b: Notification.Builder
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel(ch, "Clip banana", NotificationManager.IMPORTANCE_LOW))
            b = Notification.Builder(this, ch)
        } else {
            b = Notification.Builder(this)
        }
        val n = b.setContentTitle("Clip Katarnak").setContentText("Clips ban rahi hain... app band mat karna")
            .setSmallIcon(android.R.drawable.stat_sys_download).build()
        startForeground(1, n)
        return START_NOT_STICKY
    }
}
